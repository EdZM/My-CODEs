#ifndef DFS_H
#define DFS_H

#include "mgrafo.h"
#include "tad_fila.h"

void visitar(M_GRAFO* g, FILA* fila, char* cor, int i);
int* dfs(M_GRAFO* g);

#endif