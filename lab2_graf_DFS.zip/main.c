#include <stdio.h>
#include <stdlib.h>

#include "mgrafo.h"
#include "dfs.h"


int main(int argc, char* argv[]){

	int vert, arest, x, y;
	int *way; //será o vetor que contem o caminho percorrido
	M_GRAFO* graf = NULL;


	scanf("%d %d", &vert, &arest);
	graf = cria_mat_graf(vert);



	for (int i = 0; i < arest; i++)	{
		scanf("%d %d", &x, &y);
		inserir_aresta_m(graf, x, y);

	}
	getchar();
	

	way = dfs(graf);
	

	for (int i = graf->ordem - 1; i >= 0; i--) {
		printf("%d ", way[i]);
	}
	
	printf("\n");
	//free(way);
	//free_mat_graf(&graf);
	return 0;


return 0;	
}