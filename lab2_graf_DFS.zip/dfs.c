#include <stdio.h>
#include <stdlib.h>

#include "dfs.h"
#include "tad_fila.h"

void visitar(M_GRAFO* g, FILA* fila, char* cor, int i){
	
	cor[i] = 'c'; 		// c == cinza, indicando um caminho visitado, mas não totalmente processado


	for (int j = 0; j < g->ordem; j++)	{
		if (cor[j] == 'b' && g->adj_mat[i][j] != -1){
			visitar(g, fila, cor, j);
		}

	}
	
	
	cor[i] = 'p'; 		// marcando a posição atual com a cor PRETA, o que indica que está processado
	enfileirar(fila, i);// colocando o vertice atual na fila


}

int* dfs(M_GRAFO* g){
	
	FILA* fila = criar_fila();
	char* cor = NULL;
	int* way = NULL;
	

	cor = (char*)malloc( g->ordem * sizeof(char) );
	way = (int*)malloc( g->ordem * sizeof(int) );

	for (int i = 0; i < g->ordem; i++)	{
		cor[i] = 'b'; // b == branco(não visitado), c == cinza(visitado), p == preto(processado)
	}


	for (int i = 0; i < g->ordem; i++)	{
		for (int j = 0; j < g->ordem; j++)	{
			if (g->adj_mat[i][j] != -1 && cor[i] == 'b')
				visitar(g, fila, cor, i);
		}
	}
	

	int i;
	while( vazia(fila) != 1 ){ //enquanto nao esvaziar a fila, retira-se os primeiros elementos e os armazena em cada posição de way
		way[i] = primeiro(fila);		
		desenfileirar(fila);
		i++;
	}

	//liberar_fila(&fila);
	//free(cor);
	return way;

}
