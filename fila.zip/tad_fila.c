#include <stdio.h>
#include <stdlib.h>

#include "tad_fila.h"


FILA* criar_fila(){
	FILA* fila = (FILA*)malloc(sizeof(FILA));//alocando espaço para a fila criada
	if (fila != NULL){
		fila->inicio = NULL;
		fila->fim = NULL;
		fila->tamanho = 0;
	}
	return fila;
}


void enfileirar(FILA* fila, int valor){

	if (fila != NULL){
		NO *aux = (NO*)malloc(sizeof(NO)); //criando o nó que será enfileirado

		if(aux != NULL){

			aux->proximo = NULL; //assim garanto que o proximo no depois de aux é NULL
			aux->elemento = valor;

			if (fila->tamanho == 0){
				fila->inicio = aux;
				fila->fim = aux;

			} else {
				fila->fim->proximo = aux; 
				fila->fim = aux; 

			}

			fila->tamanho++;

		}

	}

}

void desenfileirar(FILA* fila){
	NO* aux;

	if(fila->tamanho > 0){
		aux = fila->inicio;
		fila->inicio = fila->inicio->proximo;
		free(aux);
		fila->tamanho--;

	}


}


int primeiro(FILA* fila){
	return fila->inicio->elemento;

}

int ultimo(FILA* fila){
	return fila->fim->elemento;	

} 	

int vazia(FILA* fila){
	if (fila->tamanho == 0){
		return 1;

	}else
		return 0;

}					

void liberar_fila(FILA** fila){
	while ((*fila)->tamanho > 0) desenfileirar(*fila);
	free(*fila);
	*fila = NULL;

}